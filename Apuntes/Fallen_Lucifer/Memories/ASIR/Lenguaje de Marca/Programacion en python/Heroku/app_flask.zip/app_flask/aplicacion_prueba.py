import os
from flask import Flask
from fab3 import fab


app = Flask(__name__)

@app.route('/')
def aplicacion():
    b = ""  
    try:
        with open('envivo.csv', 'r') as archivo:
            # Procesar el archivo si existe
            contenido = archivo.readlines()  
            lista = fab(contenido) 

            equipos = lista[0]
            puntaje = lista[1]

            
            for idcuar in puntaje:
                b += f"{idcuar}° Cuarto."  

                for ideq, nomeq in equipos.items():
                    punt = puntaje[idcuar].get(ideq, "N/A")  
                    b += f'{nomeq}: {punt}\n'  

                b += '<br>'  

    except FileNotFoundError:
        return 'Error: El archivo envivo.csv no existe.'
    except Exception as e:
        return f'Ocurrió un error inesperado: {e}'

    return b

if __name__ == '__main__':
    app.run(debug=True)
